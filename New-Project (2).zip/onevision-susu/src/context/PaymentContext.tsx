'use client';

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from 'react';
import { v4 as uuidv4 } from 'uuid';

// Types for Square Web Payments SDK
interface SquarePayments {
  card: () => Promise<SquareCard>;
}

interface SquareCard {
  attach: (elementId: string) => Promise<void>;
  tokenize: () => Promise<{ status: string; token?: string; errors?: Array<{ message: string }> }>;
  destroy: () => void;
}

declare global {
  interface Window {
    Square?: {
      payments: (appId: string, locationId: string) => Promise<SquarePayments>;
    };
  }
}

interface SavedCard {
  id: string;
  last4: string;
  cardBrand: string;
  expMonth?: number;
  expYear?: number;
}

interface PaymentContextType {
  isSquareLoaded: boolean;
  isProcessing: boolean;
  savedCards: SavedCard[];
  initializeCard: (elementId: string) => Promise<void>;
  tokenizeCard: () => Promise<string | null>;
  processPayment: (params: {
    amount: number;
    currency: string;
    circleId: string;
    userId: string;
    cycle: number;
    sourceId?: string;
  }) => Promise<{ success: boolean; paymentId?: string; receiptUrl?: string; error?: string }>;
  saveCard: (params: {
    customerId: string;
    cardholderName: string;
  }) => Promise<{ success: boolean; cardId?: string; error?: string }>;
  loadSavedCards: (customerId: string) => Promise<void>;
  destroyCard: () => void;
}

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

// Square SDK configuration
const SQUARE_APP_ID = process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID || 'sandbox-sq0idb-DEMO';
const SQUARE_LOCATION_ID = process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID || 'DEMO_LOCATION';

export function PaymentProvider({ children }: { children: ReactNode }) {
  const [isSquareLoaded, setIsSquareLoaded] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [squarePayments, setSquarePayments] = useState<SquarePayments | null>(null);
  const [cardInstance, setCardInstance] = useState<SquareCard | null>(null);
  const [savedCards, setSavedCards] = useState<SavedCard[]>([]);

  // Load Square Web Payments SDK
  useEffect(() => {
    const loadSquareSDK = async () => {
      if (typeof window !== 'undefined' && !window.Square) {
        const script = document.createElement('script');
        script.src = 'https://sandbox.web.squarecdn.com/v1/square.js';
        script.async = true;
        script.onload = async () => {
          if (window.Square) {
            try {
              const payments = await window.Square.payments(SQUARE_APP_ID, SQUARE_LOCATION_ID);
              setSquarePayments(payments);
              setIsSquareLoaded(true);
            } catch (error) {
              console.error('Failed to initialize Square:', error);
            }
          }
        };
        document.body.appendChild(script);
      } else if (window.Square) {
        try {
          const payments = await window.Square.payments(SQUARE_APP_ID, SQUARE_LOCATION_ID);
          setSquarePayments(payments);
          setIsSquareLoaded(true);
        } catch (error) {
          console.error('Failed to initialize Square:', error);
        }
      }
    };

    loadSquareSDK();
  }, []);

  const initializeCard = useCallback(async (elementId: string) => {
    if (!squarePayments) {
      throw new Error('Square not initialized');
    }

    // Destroy existing card instance if any
    if (cardInstance) {
      cardInstance.destroy();
    }

    const card = await squarePayments.card();
    await card.attach(`#${elementId}`);
    setCardInstance(card);
  }, [squarePayments, cardInstance]);

  const tokenizeCard = useCallback(async (): Promise<string | null> => {
    if (!cardInstance) {
      throw new Error('Card not initialized');
    }

    const result = await cardInstance.tokenize();

    if (result.status === 'OK' && result.token) {
      return result.token;
    }

    const errorMessage = result.errors?.[0]?.message || 'Card tokenization failed';
    throw new Error(errorMessage);
  }, [cardInstance]);

  const processPayment = useCallback(async (params: {
    amount: number;
    currency: string;
    circleId: string;
    userId: string;
    cycle: number;
    sourceId?: string;
  }) => {
    setIsProcessing(true);

    try {
      // If no sourceId provided, tokenize the current card
      let sourceId = params.sourceId;
      if (!sourceId) {
        sourceId = await tokenizeCard() || undefined;
        if (!sourceId) {
          return { success: false, error: 'Failed to get payment token' };
        }
      }

      const response = await fetch('/api/payments/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceId,
          amount: params.amount,
          currency: params.currency,
          circleId: params.circleId,
          userId: params.userId,
          cycle: params.cycle,
          idempotencyKey: uuidv4(),
        }),
      });

      const result = await response.json();
      return result;

    } catch (error) {
      console.error('Payment error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Payment failed'
      };
    } finally {
      setIsProcessing(false);
    }
  }, [tokenizeCard]);

  const saveCard = useCallback(async (params: {
    customerId: string;
    cardholderName: string;
  }) => {
    setIsProcessing(true);

    try {
      const token = await tokenizeCard();
      if (!token) {
        return { success: false, error: 'Failed to get card token' };
      }

      const response = await fetch('/api/payments/card', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: params.customerId,
          sourceId: token,
          cardholderName: params.cardholderName,
        }),
      });

      const result = await response.json();

      if (result.success) {
        // Reload saved cards
        await loadSavedCards(params.customerId);
      }

      return result;

    } catch (error) {
      console.error('Save card error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to save card'
      };
    } finally {
      setIsProcessing(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tokenizeCard]);

  const loadSavedCards = useCallback(async (customerId: string) => {
    try {
      const response = await fetch(`/api/payments/card?customerId=${customerId}`);
      const result = await response.json();

      if (result.success) {
        setSavedCards(result.cards);
      }
    } catch (error) {
      console.error('Load cards error:', error);
    }
  }, []);

  const destroyCard = useCallback(() => {
    if (cardInstance) {
      cardInstance.destroy();
      setCardInstance(null);
    }
  }, [cardInstance]);

  return (
    <PaymentContext.Provider
      value={{
        isSquareLoaded,
        isProcessing,
        savedCards,
        initializeCard,
        tokenizeCard,
        processPayment,
        saveCard,
        loadSavedCards,
        destroyCard,
      }}
    >
      {children}
    </PaymentContext.Provider>
  );
}

export function usePayment() {
  const context = useContext(PaymentContext);
  if (context === undefined) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
}
