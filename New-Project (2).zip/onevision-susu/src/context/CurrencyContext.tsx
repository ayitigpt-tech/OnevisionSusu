'use client';

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import {
  type CurrencyCode,
  type Currency,
  currencies,
  convertCurrency,
  formatCurrency,
  formatCurrencyCompact,
} from '@/lib/currency';

interface CurrencyContextType {
  currency: Currency;
  currencyCode: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  convert: (amount: number, fromCurrency?: CurrencyCode) => number;
  format: (amount: number, options?: { showCode?: boolean; compact?: boolean }) => string;
  formatFromUSD: (amountInUSD: number, options?: { showCode?: boolean; compact?: boolean }) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currencyCode, setCurrencyCode] = useState<CurrencyCode>('USD');

  const currency = currencies[currencyCode];

  const setCurrency = useCallback((code: CurrencyCode) => {
    setCurrencyCode(code);
    // Optionally persist to localStorage
    if (typeof window !== 'undefined') {
      localStorage.setItem('preferredCurrency', code);
    }
  }, []);

  // Convert amount from one currency to current currency
  const convert = useCallback(
    (amount: number, fromCurrency: CurrencyCode = 'USD') => {
      return convertCurrency(amount, fromCurrency, currencyCode);
    },
    [currencyCode]
  );

  // Format amount in current currency
  const format = useCallback(
    (amount: number, options?: { showCode?: boolean; compact?: boolean }) => {
      if (options?.compact) {
        return formatCurrencyCompact(amount, currencyCode);
      }
      return formatCurrency(amount, currencyCode, { showCode: options?.showCode });
    },
    [currencyCode]
  );

  // Convert from USD and format in current currency
  const formatFromUSD = useCallback(
    (amountInUSD: number, options?: { showCode?: boolean; compact?: boolean }) => {
      const converted = convertCurrency(amountInUSD, 'USD', currencyCode);
      if (options?.compact) {
        return formatCurrencyCompact(converted, currencyCode);
      }
      return formatCurrency(converted, currencyCode, { showCode: options?.showCode });
    },
    [currencyCode]
  );

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        currencyCode,
        setCurrency,
        convert,
        format,
        formatFromUSD,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}
