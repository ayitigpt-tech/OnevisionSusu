import { SquareClient, SquareEnvironment } from 'square';

// Square API Configuration
// In production, these would come from environment variables
const SQUARE_ACCESS_TOKEN = process.env.SQUARE_ACCESS_TOKEN || '';
const SQUARE_ENVIRONMENT = process.env.SQUARE_ENVIRONMENT === 'production'
  ? SquareEnvironment.Production
  : SquareEnvironment.Sandbox;
const SQUARE_LOCATION_ID = process.env.SQUARE_LOCATION_ID || '';
const SQUARE_APPLICATION_ID = process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID || '';

// Initialize Square client (server-side only)
export const squareClient = new SquareClient({
  token: SQUARE_ACCESS_TOKEN,
  environment: SQUARE_ENVIRONMENT,
});

// Export configuration for client-side use
export const squareConfig = {
  applicationId: SQUARE_APPLICATION_ID,
  locationId: SQUARE_LOCATION_ID,
  environment: SQUARE_ENVIRONMENT === SquareEnvironment.Production ? 'production' : 'sandbox',
};

// Types for payment processing
export interface PaymentRequest {
  sourceId: string; // Payment token from Square Web Payments SDK
  amount: number; // Amount in cents
  currency: string;
  circleId: string;
  userId: string;
  cycle: number;
  idempotencyKey: string;
  note?: string;
}

export interface PaymentResult {
  success: boolean;
  paymentId?: string;
  receiptUrl?: string;
  error?: string;
}

export interface CustomerRequest {
  email: string;
  givenName: string;
  familyName: string;
  phoneNumber?: string;
  referenceId: string; // User ID from our system
}

export interface CustomerResult {
  success: boolean;
  customerId?: string;
  error?: string;
}

export interface CardOnFileRequest {
  customerId: string;
  sourceId: string; // Card token from Square Web Payments SDK
  cardholderName: string;
}

export interface CardOnFileResult {
  success: boolean;
  cardId?: string;
  last4?: string;
  cardBrand?: string;
  error?: string;
}

// Helper to convert dollars to cents
export function dollarsToCents(dollars: number): bigint {
  return BigInt(Math.round(dollars * 100));
}

// Helper to convert cents to dollars
export function centsToDollars(cents: bigint | number): number {
  return Number(cents) / 100;
}

// Generate idempotency key for Square API calls
export function generateIdempotencyKey(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
}
