export type CurrencyCode = 'USD' | 'HTG' | 'EUR';

export interface Currency {
  code: CurrencyCode;
  name: string;
  symbol: string;
  flag: string;
  locale: string;
}

export const currencies: Record<CurrencyCode, Currency> = {
  USD: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    flag: '🇺🇸',
    locale: 'en-US',
  },
  HTG: {
    code: 'HTG',
    name: 'Haitian Gourde',
    symbol: 'G',
    flag: '🇭🇹',
    locale: 'fr-HT',
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    flag: '🇪🇺',
    locale: 'fr-FR',
  },
};

// Exchange rates relative to USD (these would normally come from an API)
// As of Feb 2026 (approximate rates)
export const exchangeRates: Record<CurrencyCode, number> = {
  USD: 1,
  HTG: 132.5, // 1 USD = ~132.5 HTG
  EUR: 0.92,  // 1 USD = ~0.92 EUR
};

export function convertCurrency(
  amount: number,
  fromCurrency: CurrencyCode,
  toCurrency: CurrencyCode
): number {
  if (fromCurrency === toCurrency) return amount;

  // Convert to USD first, then to target currency
  const amountInUSD = amount / exchangeRates[fromCurrency];
  const convertedAmount = amountInUSD * exchangeRates[toCurrency];

  return convertedAmount;
}

export function formatCurrency(
  amount: number,
  currencyCode: CurrencyCode,
  options?: {
    showSymbol?: boolean;
    showCode?: boolean;
    decimals?: number;
  }
): string {
  const { showSymbol = true, showCode = false, decimals = 2 } = options || {};
  const currency = currencies[currencyCode];

  // For HTG, use no decimals as it's a larger denomination
  const actualDecimals = currencyCode === 'HTG' ? 0 : decimals;

  const formatter = new Intl.NumberFormat(currency.locale, {
    minimumFractionDigits: actualDecimals,
    maximumFractionDigits: actualDecimals,
  });

  const formattedNumber = formatter.format(amount);

  if (showSymbol && showCode) {
    return `${currency.symbol}${formattedNumber} ${currency.code}`;
  } else if (showSymbol) {
    return `${currency.symbol}${formattedNumber}`;
  } else if (showCode) {
    return `${formattedNumber} ${currency.code}`;
  }

  return formattedNumber;
}

export function formatCurrencyCompact(
  amount: number,
  currencyCode: CurrencyCode
): string {
  const currency = currencies[currencyCode];

  if (amount >= 1000000) {
    return `${currency.symbol}${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `${currency.symbol}${(amount / 1000).toFixed(1)}K`;
  }

  return formatCurrency(amount, currencyCode);
}

// Get currency display info for UI
export function getCurrencyInfo(code: CurrencyCode): Currency {
  return currencies[code];
}

// Get all available currencies as array
export function getAllCurrencies(): Currency[] {
  return Object.values(currencies);
}
