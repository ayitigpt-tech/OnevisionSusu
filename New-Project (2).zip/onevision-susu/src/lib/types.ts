// User types
export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatar?: string;
  trustScore: number;
  createdAt: Date;
  circles: string[];
}

// Circle types
export type CircleType = 'rotating' | 'target' | 'community';
export type PayoutOrder = 'random' | 'custom' | 'rotating';
export type Frequency = 'weekly' | 'biweekly' | 'monthly';
export type ContributionStatus = 'paid' | 'pending' | 'overdue';
export type CircleStatus = 'pending' | 'active' | 'completed' | 'paused';

export interface CircleMember {
  userId: string;
  name: string;
  avatar?: string;
  trustScore: number;
  joinedAt: Date;
  payoutOrder: number;
  contributionStatus: ContributionStatus;
  totalContributed: number;
  hasReceivedPayout: boolean;
}

export interface Circle {
  id: string;
  name: string;
  description: string;
  type: CircleType;
  creatorId: string;
  contributionAmount: number;
  frequency: Frequency;
  totalMembers: number;
  currentMembers: CircleMember[];
  payoutOrder: PayoutOrder;
  startDate: Date;
  status: CircleStatus;
  currentCycle: number;
  totalCycles: number;
  nextPayoutDate: Date;
  nextPayoutRecipient: string;
  totalPot: number;
  inviteCode: string;
  createdAt: Date;
}

export interface Contribution {
  id: string;
  circleId: string;
  userId: string;
  amount: number;
  cycle: number;
  paidAt: Date;
  paymentMethod: string;
  transactionId: string;
}

export interface Payout {
  id: string;
  circleId: string;
  recipientId: string;
  amount: number;
  cycle: number;
  paidAt: Date;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

export interface Activity {
  id: string;
  circleId: string;
  userId: string;
  userName: string;
  type: 'contribution' | 'payout' | 'join' | 'message' | 'reminder';
  message: string;
  createdAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'reminder' | 'payout' | 'contribution' | 'system';
  read: boolean;
  createdAt: Date;
}

// Form types
export interface CreateCircleForm {
  name: string;
  description: string;
  type: CircleType;
  contributionAmount: number;
  frequency: Frequency;
  totalMembers: number;
  payoutOrder: PayoutOrder;
  startDate: string;
}

export interface LoginForm {
  email: string;
  password: string;
}

export interface SignUpForm {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone?: string;
}
