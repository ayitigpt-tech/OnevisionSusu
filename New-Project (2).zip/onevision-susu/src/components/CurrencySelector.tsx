'use client';

import { useCurrency } from '@/context/CurrencyContext';
import { getAllCurrencies, type CurrencyCode } from '@/lib/currency';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

export function CurrencySelector() {
  const { currency, setCurrency } = useCurrency();
  const allCurrencies = getAllCurrencies();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-9 px-3 gap-2 text-gray-600 hover:text-teal-700 hover:bg-teal-50"
        >
          <span className="text-lg">{currency.flag}</span>
          <span className="font-medium">{currency.code}</span>
          <svg
            className="w-3 h-3 opacity-50"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        {allCurrencies.map((curr) => (
          <DropdownMenuItem
            key={curr.code}
            onClick={() => setCurrency(curr.code as CurrencyCode)}
            className={`flex items-center gap-3 cursor-pointer ${
              currency.code === curr.code ? 'bg-teal-50 text-teal-700' : ''
            }`}
          >
            <span className="text-lg">{curr.flag}</span>
            <div className="flex-1">
              <p className="font-medium">{curr.code}</p>
              <p className="text-xs text-gray-500">{curr.name}</p>
            </div>
            {currency.code === curr.code && (
              <svg
                className="w-4 h-4 text-teal-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            )}
          </DropdownMenuItem>
        ))}
        <div className="px-2 py-2 border-t mt-1">
          <p className="text-xs text-gray-400 text-center">
            Rates updated daily
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
