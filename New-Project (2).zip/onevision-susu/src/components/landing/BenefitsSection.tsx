'use client';

export function BenefitsSection() {
  const benefits = [
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        </svg>
      ),
      title: 'Real-Time Transparency',
      description:
        'Everyone sees the same information. Track contributions, payouts, and member status in real-time. No more confusion or disputes.',
      color: 'teal',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
      ),
      title: 'Automatic Contributions',
      description:
        'Set it and forget it. Schedule automatic payments so you never miss a contribution. Stay on track effortlessly.',
      color: 'amber',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'Guaranteed Payouts',
      description:
        "When it's your turn, you get paid. Our trust system and secure payment processing ensure every member receives their payout.",
      color: 'green',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'Community Trust System',
      description:
        'Build your reputation over time. Our trust scores help communities identify reliable members and build stronger circles.',
      color: 'rose',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      title: 'Mobile-First Design',
      description:
        'Manage your circles anywhere, anytime. Our PWA works beautifully on any device - phone, tablet, or desktop.',
      color: 'purple',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
      ),
      title: 'Smart Notifications',
      description:
        'Never miss a payment or payout. Get email and push reminders for due contributions, upcoming turns, and circle updates.',
      color: 'cyan',
    },
  ];

  const colorClasses: Record<string, { bg: string; icon: string; border: string }> = {
    teal: { bg: 'bg-teal-50', icon: 'text-teal-600', border: 'border-teal-200' },
    amber: { bg: 'bg-amber-50', icon: 'text-amber-600', border: 'border-amber-200' },
    green: { bg: 'bg-green-50', icon: 'text-green-600', border: 'border-green-200' },
    rose: { bg: 'bg-rose-50', icon: 'text-rose-600', border: 'border-rose-200' },
    purple: { bg: 'bg-purple-50', icon: 'text-purple-600', border: 'border-purple-200' },
    cyan: { bg: 'bg-cyan-50', icon: 'text-cyan-600', border: 'border-cyan-200' },
  };

  return (
    <section className="py-24 bg-gradient-to-b from-white to-teal-50/50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-teal-100 text-teal-700 text-sm font-semibold rounded-full mb-4">
            Why OneVision Susu?
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-teal-900 mb-6">
            The Modern Way to Save <span className="text-gradient">Together</span>
          </h2>
          <p className="text-lg text-gray-600">
            We've taken the traditional rotating savings system trusted by generations and made it
            digital, transparent, and secure. Everything you love about susu, with none of the
            headaches.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className={`group relative p-8 rounded-2xl bg-white border ${
                colorClasses[benefit.color].border
              } card-hover`}
            >
              <div
                className={`w-16 h-16 rounded-2xl ${colorClasses[benefit.color].bg} ${
                  colorClasses[benefit.color].icon
                } flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
              >
                {benefit.icon}
              </div>
              <h3 className="font-display text-xl font-bold text-teal-900 mb-3">{benefit.title}</h3>
              <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
