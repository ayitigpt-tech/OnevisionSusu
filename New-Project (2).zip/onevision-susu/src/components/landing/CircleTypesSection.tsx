'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useCurrency } from '@/context/CurrencyContext';

export function CircleTypesSection() {
  const { formatFromUSD } = useCurrency();

  const circleTypes = [
    {
      type: 'rotating',
      title: 'Rotating Circle',
      subtitle: 'Classic Susu',
      description:
        'The traditional rotating savings model. Each member contributes regularly, and one member receives the full pot each cycle until everyone has had their turn.',
      features: [
        'Equal contributions for all',
        'Rotating payouts each cycle',
        'Fixed duration based on members',
        'Perfect for groups of 5-20 people',
      ],
      example: `10 members × ${formatFromUSD(100)}/month = ${formatFromUSD(1000)} payout each turn`,
      color: 'teal',
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
          />
        </svg>
      ),
    },
    {
      type: 'target',
      title: 'Target Savings',
      subtitle: 'Goal-Based',
      description:
        'Save toward a specific goal together. Great for weddings, graduations, community projects, or any shared target where everyone contributes toward one purpose.',
      features: [
        'Flexible contribution amounts',
        'Single beneficiary or shared goal',
        'Target amount milestone tracking',
        'Perfect for specific events',
      ],
      example: `Help Rosa save ${formatFromUSD(5000)} for her wedding!`,
      color: 'amber',
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </svg>
      ),
    },
    {
      type: 'community',
      title: 'Community Fund',
      subtitle: 'Ongoing Support',
      description:
        'An ongoing pool for community needs, emergencies, or mutual aid. Members contribute regularly and funds can be distributed to those in need when they need it.',
      features: [
        'Flexible withdrawals for emergencies',
        'Community-voted disbursements',
        'Rolling membership',
        'Perfect for mutual aid groups',
      ],
      example: 'Emergency fund for church members or neighborhood group',
      color: 'rose',
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
          />
        </svg>
      ),
    },
  ];

  const colorClasses: Record<
    string,
    { bg: string; border: string; icon: string; badge: string; button: string }
  > = {
    teal: {
      bg: 'bg-gradient-to-br from-teal-50 to-teal-100/50',
      border: 'border-teal-200 hover:border-teal-300',
      icon: 'bg-teal-500 text-white',
      badge: 'bg-teal-100 text-teal-700',
      button: 'bg-teal-600 hover:bg-teal-700 text-white',
    },
    amber: {
      bg: 'bg-gradient-to-br from-amber-50 to-amber-100/50',
      border: 'border-amber-200 hover:border-amber-300',
      icon: 'bg-amber-500 text-white',
      badge: 'bg-amber-100 text-amber-700',
      button: 'bg-amber-600 hover:bg-amber-700 text-white',
    },
    rose: {
      bg: 'bg-gradient-to-br from-rose-50 to-rose-100/50',
      border: 'border-rose-200 hover:border-rose-300',
      icon: 'bg-rose-500 text-white',
      badge: 'bg-rose-100 text-rose-700',
      button: 'bg-rose-600 hover:bg-rose-700 text-white',
    },
  };

  return (
    <section className="py-24 bg-gradient-to-b from-teal-50/50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-teal-100 text-teal-700 text-sm font-semibold rounded-full mb-4">
            Circle Types
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-teal-900 mb-6">
            Choose Your <span className="text-gradient">Savings Style</span>
          </h2>
          <p className="text-lg text-gray-600">
            Different goals, different circles. Pick the format that works best for your community.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {circleTypes.map((circle, index) => (
            <div
              key={index}
              className={`relative rounded-3xl border-2 ${colorClasses[circle.color].border} ${
                colorClasses[circle.color].bg
              } p-8 transition-all duration-300 hover:shadow-xl hover:-translate-y-1`}
            >
              {/* Icon */}
              <div
                className={`w-16 h-16 rounded-2xl ${colorClasses[circle.color].icon} flex items-center justify-center mb-6 shadow-lg`}
              >
                {circle.icon}
              </div>

              {/* Header */}
              <div className="mb-4">
                <span
                  className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${
                    colorClasses[circle.color].badge
                  } mb-2`}
                >
                  {circle.subtitle}
                </span>
                <h3 className="font-display text-2xl font-bold text-gray-900">{circle.title}</h3>
              </div>

              {/* Description */}
              <p className="text-gray-600 mb-6">{circle.description}</p>

              {/* Features */}
              <ul className="space-y-2 mb-6">
                {circle.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                    <svg
                      className={`w-5 h-5 mt-0.5 ${
                        circle.color === 'teal'
                          ? 'text-teal-500'
                          : circle.color === 'amber'
                            ? 'text-amber-500'
                            : 'text-rose-500'
                      }`}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>

              {/* Example */}
              <div className="bg-white/60 backdrop-blur rounded-xl p-4 mb-6">
                <p className="text-sm text-gray-500 mb-1">Example:</p>
                <p className="font-semibold text-gray-800">{circle.example}</p>
              </div>

              {/* CTA */}
              <Button asChild className={`w-full ${colorClasses[circle.color].button}`}>
                <Link href={`/circles/create?type=${circle.type}`}>Start {circle.title}</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
