'use client';

export function HowItWorksSection() {
  const steps = [
    {
      number: '01',
      title: 'Create or Join a Circle',
      description:
        'Start your own savings circle with family and friends, or join an existing one with an invite code. Set contribution amounts, frequency, and the number of members.',
      image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400',
    },
    {
      number: '02',
      title: 'Contribute Each Cycle',
      description:
        "Make your contribution each week or month via Square. Set up automatic payments so you never miss a deadline. Everyone's contributions are tracked transparently.",
      image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400',
    },
    {
      number: '03',
      title: 'Get Your Payout',
      description:
        "When it's your turn, receive the full pot directly to your bank account. Use it for emergencies, weddings, business investments, or that dream vacation back home!",
      image: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=400',
    },
    {
      number: '04',
      title: 'Keep the Circle Going',
      description:
        'Continue contributing until everyone has received their payout. Build trust, strengthen community bonds, and start a new circle when you\'re ready!',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400',
    },
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-40 -left-20 w-60 h-60 bg-amber-100/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 -right-20 w-80 h-80 bg-teal-100/30 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-amber-100 text-amber-700 text-sm font-semibold rounded-full mb-4">
            Simple Process
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-teal-900 mb-6">
            How <span className="text-gold-gradient">Susu</span> Works
          </h2>
          <p className="text-lg text-gray-600">
            A time-tested system used by communities worldwide. Simple, fair, and now fully digital.
          </p>
        </div>

        <div className="space-y-16 lg:space-y-24">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`flex flex-col ${
                index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
              } items-center gap-8 lg:gap-16`}
            >
              {/* Image */}
              <div className="flex-1 w-full">
                <div className="relative">
                  <div
                    className={`absolute -inset-4 bg-gradient-to-r ${
                      index % 2 === 0
                        ? 'from-teal-200 to-teal-100'
                        : 'from-amber-200 to-amber-100'
                    } rounded-3xl transform ${
                      index % 2 === 0 ? 'rotate-2' : '-rotate-2'
                    }`}
                  />
                  <div className="relative rounded-2xl overflow-hidden shadow-xl">
                    <img
                      src={step.image}
                      alt={step.title}
                      className="w-full aspect-[4/3] object-cover"
                    />
                  </div>
                  <div
                    className={`absolute -bottom-6 ${
                      index % 2 === 0 ? '-right-6' : '-left-6'
                    } w-20 h-20 bg-gradient-to-br ${
                      index % 2 === 0
                        ? 'from-teal-500 to-teal-700'
                        : 'from-amber-400 to-amber-600'
                    } rounded-2xl flex items-center justify-center shadow-lg`}
                  >
                    <span className="text-2xl font-display font-bold text-white">
                      {step.number}
                    </span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 w-full">
                <h3 className="font-display text-2xl md:text-3xl font-bold text-teal-900 mb-4">
                  {step.title}
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed mb-6">{step.description}</p>

                {/* Additional info based on step */}
                {index === 0 && (
                  <div className="flex flex-wrap gap-3">
                    <span className="px-3 py-1.5 bg-teal-50 text-teal-700 text-sm font-medium rounded-full">
                      Rotating Circles
                    </span>
                    <span className="px-3 py-1.5 bg-amber-50 text-amber-700 text-sm font-medium rounded-full">
                      Target Savings
                    </span>
                    <span className="px-3 py-1.5 bg-green-50 text-green-700 text-sm font-medium rounded-full">
                      Community Fund
                    </span>
                  </div>
                )}
                {index === 1 && (
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                        <svg
                          className="w-5 h-5 text-teal-600"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                          />
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-gray-700">Card</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                        <svg
                          className="w-5 h-5 text-teal-600"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"
                          />
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-gray-700">Bank</span>
                    </div>
                    <span className="text-sm text-gray-500">via Square</span>
                  </div>
                )}
                {index === 2 && (
                  <div className="bg-gradient-to-r from-green-50 to-teal-50 border border-green-200 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                        <svg
                          className="w-6 h-6 text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-green-800">100% to You</p>
                        <p className="text-sm text-green-600">
                          No hidden fees on your payout (platform fee charged separately)
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
