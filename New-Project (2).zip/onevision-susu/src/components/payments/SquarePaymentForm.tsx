'use client';

import { useEffect, useState, useCallback } from 'react';
import { usePayment } from '@/context/PaymentContext';
import { useCurrency } from '@/context/CurrencyContext';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface SquarePaymentFormProps {
  amount: number; // Amount in USD
  circleId: string;
  circleName: string;
  userId: string;
  cycle: number;
  onSuccess?: (paymentId: string, receiptUrl?: string) => void;
  onCancel?: () => void;
}

export function SquarePaymentForm({
  amount,
  circleId,
  circleName,
  userId,
  cycle,
  onSuccess,
  onCancel,
}: SquarePaymentFormProps) {
  const { isSquareLoaded, isProcessing, initializeCard, processPayment, savedCards } = usePayment();
  const { formatFromUSD, currency } = useCurrency();
  const [cardInitialized, setCardInitialized] = useState(false);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [cardholderName, setCardholderName] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Initialize card input when Square is loaded
  useEffect(() => {
    if (isSquareLoaded && !cardInitialized && !selectedCard) {
      initializeCard('card-container')
        .then(() => setCardInitialized(true))
        .catch((err) => {
          console.error('Card init error:', err);
          setError('Failed to load payment form');
        });
    }
  }, [isSquareLoaded, cardInitialized, selectedCard, initializeCard]);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!cardholderName.trim() && !selectedCard) {
      setError('Please enter cardholder name');
      return;
    }

    try {
      const result = await processPayment({
        amount,
        currency: 'USD', // Square processes in USD
        circleId,
        userId,
        cycle,
        sourceId: selectedCard || undefined,
      });

      if (result.success) {
        toast.success('Payment successful!');
        onSuccess?.(result.paymentId!, result.receiptUrl);
      } else {
        setError(result.error || 'Payment failed');
        toast.error(result.error || 'Payment failed');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Payment failed';
      setError(errorMessage);
      toast.error(errorMessage);
    }
  }, [amount, circleId, userId, cycle, selectedCard, cardholderName, processPayment, onSuccess]);

  if (!isSquareLoaded) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-teal-500 border-t-transparent" />
        <span className="ml-3 text-gray-600">Loading payment form...</span>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Payment Summary */}
      <div className="bg-gradient-to-r from-teal-50 to-amber-50 rounded-xl p-6">
        <div className="text-center">
          <p className="text-sm text-gray-600">You're contributing to</p>
          <p className="font-display text-lg font-bold text-teal-900">{circleName}</p>
          <p className="text-3xl font-bold text-teal-700 mt-2">{formatFromUSD(amount)}</p>
          <p className="text-sm text-gray-500 mt-1">Cycle {cycle}</p>
        </div>
      </div>

      {/* Saved Cards */}
      {savedCards.length > 0 && (
        <div className="space-y-3">
          <Label>Use saved card</Label>
          <div className="grid gap-2">
            {savedCards.map((card) => (
              <button
                key={card.id}
                type="button"
                onClick={() => {
                  setSelectedCard(card.id);
                  setCardInitialized(false);
                }}
                className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${
                  selectedCard === card.id
                    ? 'border-teal-500 bg-teal-50'
                    : 'border-gray-200 hover:border-teal-200'
                }`}
              >
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                  <CardBrandIcon brand={card.cardBrand} />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium text-gray-900">
                    {card.cardBrand} •••• {card.last4}
                  </p>
                  {card.expMonth && card.expYear && (
                    <p className="text-sm text-gray-500">
                      Expires {card.expMonth}/{card.expYear}
                    </p>
                  )}
                </div>
                {selectedCard === card.id && (
                  <svg className="w-5 h-5 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setSelectedCard(null);
                setTimeout(() => {
                  initializeCard('card-container')
                    .then(() => setCardInitialized(true))
                    .catch(console.error);
                }, 100);
              }}
              className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${
                !selectedCard
                  ? 'border-teal-500 bg-teal-50'
                  : 'border-gray-200 hover:border-teal-200'
              }`}
            >
              <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <span className="font-medium text-gray-900">Use a new card</span>
            </button>
          </div>
        </div>
      )}

      {/* New Card Form */}
      {!selectedCard && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cardholder">Cardholder Name</Label>
            <Input
              id="cardholder"
              placeholder="Name on card"
              value={cardholderName}
              onChange={(e) => setCardholderName(e.target.value)}
              required={!selectedCard}
            />
          </div>

          <div className="space-y-2">
            <Label>Card Details</Label>
            <div
              id="card-container"
              className="min-h-[50px] p-4 border border-gray-200 rounded-xl bg-white"
            >
              {!cardInitialized && (
                <div className="flex items-center justify-center text-gray-400">
                  <span className="animate-pulse">Loading card input...</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-center gap-2 text-red-700">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-sm">{error}</span>
          </div>
        </div>
      )}

      {/* Security Notice */}
      <div className="flex items-center gap-3 text-sm text-gray-500">
        <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
        <span>Your payment is secured with 256-bit SSL encryption via Square</span>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <Button
          type="submit"
          disabled={isProcessing || (!cardInitialized && !selectedCard)}
          className="flex-1 h-12 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600"
        >
          {isProcessing ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Processing...
            </span>
          ) : (
            `Pay ${formatFromUSD(amount)}`
          )}
        </Button>
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel} className="h-12">
            Cancel
          </Button>
        )}
      </div>

      {/* Square Badge */}
      <div className="text-center text-xs text-gray-400">
        Powered by <span className="font-semibold">Square</span>
      </div>
    </form>
  );
}

function CardBrandIcon({ brand }: { brand: string }) {
  // Simple card brand icons
  const brands: Record<string, string> = {
    VISA: 'V',
    MASTERCARD: 'MC',
    AMERICAN_EXPRESS: 'AX',
    DISCOVER: 'D',
    JCB: 'JCB',
  };

  return (
    <span className="text-sm font-bold text-gray-600">
      {brands[brand] || brand.slice(0, 2)}
    </span>
  );
}
