'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SquarePaymentForm } from './SquarePaymentForm';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  circleId: string;
  circleName: string;
  userId: string;
  cycle: number;
  onSuccess?: (paymentId: string, receiptUrl?: string) => void;
}

export function PaymentModal({
  isOpen,
  onClose,
  amount,
  circleId,
  circleName,
  userId,
  cycle,
  onSuccess,
}: PaymentModalProps) {
  const handleSuccess = (paymentId: string, receiptUrl?: string) => {
    onSuccess?.(paymentId, receiptUrl);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Make a Contribution</DialogTitle>
        </DialogHeader>
        <SquarePaymentForm
          amount={amount}
          circleId={circleId}
          circleName={circleName}
          userId={userId}
          cycle={cycle}
          onSuccess={handleSuccess}
          onCancel={onClose}
        />
      </DialogContent>
    </Dialog>
  );
}
