'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import type { CircleType, Frequency, PayoutOrder } from '@/lib/types';
import { useCurrency } from '@/context/CurrencyContext';

export default function CreateCirclePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const defaultType = (searchParams.get('type') as CircleType) || 'rotating';
  const { formatFromUSD, currency } = useCurrency();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: defaultType,
    contributionAmount: '',
    frequency: 'monthly' as Frequency,
    totalMembers: '',
    payoutOrder: 'rotating' as PayoutOrder,
    startDate: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.contributionAmount || !formData.totalMembers) {
      toast.error('Please fill in all required fields');
      return;
    }
    setIsLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    toast.success('Circle created successfully!');
    router.push('/dashboard');
  };

  const circleTypeInfo = {
    rotating: {
      title: 'Rotating Circle',
      description: 'Classic susu - each member receives the pot on their turn',
      icon: '🔄',
    },
    target: {
      title: 'Target Savings',
      description: 'Save toward a specific goal together',
      icon: '🎯',
    },
    community: {
      title: 'Community Fund',
      description: 'Ongoing pool for emergencies and mutual aid',
      icon: '❤️',
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50/50 to-white">
      <Header />

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <ol className="flex items-center gap-2 text-sm">
            <li>
              <Link href="/dashboard" className="text-teal-600 hover:underline">
                Dashboard
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li className="text-gray-600">Create Circle</li>
          </ol>
        </nav>

        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-teal-900 mb-2">Create a New Circle</h1>
          <p className="text-gray-600">
            Set up your savings circle and invite family or friends to join.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Circle Type Selection */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <h2 className="font-display text-lg font-bold text-teal-900 mb-4">Circle Type</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(Object.keys(circleTypeInfo) as CircleType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({ ...formData, type })}
                  className={`p-4 rounded-xl border-2 text-left transition-all ${
                    formData.type === type
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-teal-200'
                  }`}
                >
                  <div className="text-2xl mb-2">{circleTypeInfo[type].icon}</div>
                  <h3 className="font-semibold text-teal-900">{circleTypeInfo[type].title}</h3>
                  <p className="text-xs text-gray-600 mt-1">{circleTypeInfo[type].description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Basic Info */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <h2 className="font-display text-lg font-bold text-teal-900 mb-4">Basic Information</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Circle Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Queens Family Vacation Fund"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the purpose of this circle..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Contribution Settings */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <h2 className="font-display text-lg font-bold text-teal-900 mb-4">Contribution Settings</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Contribution Amount ({currency.code}) *</Label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">{currency.symbol}</span>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="100"
                    value={formData.contributionAmount}
                    onChange={(e) => setFormData({ ...formData, contributionAmount: e.target.value })}
                    className="h-12 pl-8"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency *</Label>
                <Select
                  value={formData.frequency}
                  onValueChange={(value) => setFormData({ ...formData, frequency: value as Frequency })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="members">Number of Members *</Label>
                <Input
                  id="members"
                  type="number"
                  placeholder="10"
                  min="2"
                  max="50"
                  value={formData.totalMembers}
                  onChange={(e) => setFormData({ ...formData, totalMembers: e.target.value })}
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="payoutOrder">Payout Order</Label>
                <Select
                  value={formData.payoutOrder}
                  onValueChange={(value) => setFormData({ ...formData, payoutOrder: value as PayoutOrder })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rotating">Rotating (in order joined)</SelectItem>
                    <SelectItem value="random">Random (shuffled)</SelectItem>
                    <SelectItem value="custom">Custom (you decide)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="h-12"
                />
              </div>
            </div>
          </div>

          {/* Summary */}
          {formData.contributionAmount && formData.totalMembers && (
            <div className="bg-gradient-to-r from-teal-50 to-amber-50 rounded-2xl border border-teal-200 p-6">
              <h2 className="font-display text-lg font-bold text-teal-900 mb-4">Circle Summary</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Per Member</p>
                  <p className="text-xl font-bold text-teal-800">
                    {currency.symbol}{formData.contributionAmount}/{formData.frequency}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Pot Size</p>
                  <p className="text-xl font-bold text-green-700">
                    {currency.symbol}{(Number(formData.contributionAmount) * Number(formData.totalMembers)).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Cycles</p>
                  <p className="text-xl font-bold text-teal-800">{formData.totalMembers}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Duration</p>
                  <p className="text-xl font-bold text-teal-800">
                    {formData.totalMembers}{' '}
                    {formData.frequency === 'weekly'
                      ? 'weeks'
                      : formData.frequency === 'biweekly'
                        ? 'bi-weeks'
                        : 'months'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 h-12 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600 text-lg"
            >
              {isLoading ? (
                <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
              ) : (
                'Create Circle'
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="h-12"
              onClick={() => router.back()}
            >
              Cancel
            </Button>
          </div>

          {/* Payment Info */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <svg className="w-6 h-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Secure Payments via Square</h3>
                <p className="text-sm text-gray-600 mt-1">
                  All contributions are processed securely through Square. Members can pay via
                  card or bank transfer. Payouts are sent directly to your linked account.
                </p>
              </div>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
