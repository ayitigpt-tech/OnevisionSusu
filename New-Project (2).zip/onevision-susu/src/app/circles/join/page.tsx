'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { mockCircles } from '@/lib/mock-data';
import { useCurrency } from '@/context/CurrencyContext';

export default function JoinCirclePage() {
  const router = useRouter();
  const [inviteCode, setInviteCode] = useState('');
  const [foundCircle, setFoundCircle] = useState<typeof mockCircles[0] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const { formatFromUSD } = useCurrency();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) {
      toast.error('Please enter an invite code');
      return;
    }
    setIsSearching(true);
    await new Promise((resolve) => setTimeout(resolve, 800));

    const circle = mockCircles.find(
      (c) => c.inviteCode.toLowerCase() === inviteCode.toLowerCase()
    );

    if (circle) {
      setFoundCircle(circle);
    } else {
      toast.error('Circle not found. Check your invite code.');
    }
    setIsSearching(false);
  };

  const handleJoin = async () => {
    setIsJoining(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    toast.success('Successfully joined the circle!');
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50/50 to-white">
      <Header />

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <ol className="flex items-center gap-2 text-sm">
            <li>
              <Link href="/dashboard" className="text-teal-600 hover:underline">
                Dashboard
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li className="text-gray-600">Join Circle</li>
          </ol>
        </nav>

        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
          </div>
          <h1 className="font-display text-3xl font-bold text-teal-900 mb-2">Join a Circle</h1>
          <p className="text-gray-600">
            Enter the invite code shared by your circle organizer to join.
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm mb-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="code">Invite Code</Label>
              <div className="flex gap-3">
                <Input
                  id="code"
                  placeholder="e.g., QFV2024"
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                  className="h-12 text-lg font-mono tracking-wider"
                />
                <Button
                  type="submit"
                  disabled={isSearching}
                  className="h-12 px-6 bg-gradient-to-r from-teal-600 to-teal-500"
                >
                  {isSearching ? (
                    <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                  ) : (
                    'Search'
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>

        {/* Found Circle */}
        {foundCircle && (
          <div className="bg-white rounded-2xl border-2 border-teal-200 p-6 shadow-lg">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <span className="text-green-700 font-semibold">Circle Found!</span>
            </div>

            <h2 className="font-display text-2xl font-bold text-teal-900 mb-2">{foundCircle.name}</h2>
            <p className="text-gray-600 mb-6">{foundCircle.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-teal-50 rounded-xl p-4">
                <p className="text-sm text-gray-600">Contribution</p>
                <p className="text-xl font-bold text-teal-800">
                  {formatFromUSD(foundCircle.contributionAmount)}/{foundCircle.frequency}
                </p>
              </div>
              <div className="bg-amber-50 rounded-xl p-4">
                <p className="text-sm text-gray-600">Pot Size</p>
                <p className="text-xl font-bold text-amber-700">
                  {formatFromUSD(foundCircle.contributionAmount * foundCircle.totalMembers)}
                </p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-sm text-gray-600">Members</p>
                <p className="text-xl font-bold text-gray-800">
                  {foundCircle.currentMembers.length}/{foundCircle.totalMembers}
                </p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-sm text-gray-600">Circle Type</p>
                <p className="text-xl font-bold text-gray-800 capitalize">{foundCircle.type}</p>
              </div>
            </div>

            {/* Current Members Preview */}
            <div className="mb-6">
              <p className="text-sm text-gray-600 mb-2">Current Members:</p>
              <div className="flex -space-x-2">
                {foundCircle.currentMembers.slice(0, 5).map((member, i) => (
                  <img
                    key={i}
                    src={member.avatar}
                    alt={member.name}
                    className="w-10 h-10 rounded-full border-2 border-white object-cover"
                  />
                ))}
                {foundCircle.currentMembers.length > 5 && (
                  <div className="w-10 h-10 rounded-full bg-teal-100 border-2 border-white flex items-center justify-center text-sm font-medium text-teal-700">
                    +{foundCircle.currentMembers.length - 5}
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleJoin}
                disabled={isJoining}
                className="flex-1 h-12 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600 text-lg"
              >
                {isJoining ? (
                  <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                ) : (
                  'Join This Circle'
                )}
              </Button>
              <Button
                variant="outline"
                onClick={() => setFoundCircle(null)}
                className="h-12"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Tips */}
        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-2xl p-6">
          <h3 className="font-semibold text-amber-900 mb-3 flex items-center gap-2">
            <span className="text-xl">💡</span> Tips
          </h3>
          <ul className="space-y-2 text-sm text-amber-800">
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              Ask your circle organizer for the invite code if you don't have it
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              Invite codes are case-insensitive (QFV2024 = qfv2024)
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              Once you join, you'll be assigned a payout position
            </li>
          </ul>
        </div>

        {/* Create Instead */}
        <div className="mt-6 text-center">
          <p className="text-gray-600">
            Want to start your own circle?{' '}
            <Link href="/circles/create" className="text-teal-600 font-semibold hover:underline">
              Create a Circle
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
