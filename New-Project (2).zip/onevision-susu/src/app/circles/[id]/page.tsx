'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { mockCircles, mockActivities } from '@/lib/mock-data';
import { useCurrency } from '@/context/CurrencyContext';
import { useAuth } from '@/context/AuthContext';
import { PaymentModal } from '@/components/payments/PaymentModal';

export default function CircleDetailPage() {
  const params = useParams();
  const circle = mockCircles.find((c) => c.id === params.id) || mockCircles[0];
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [message, setMessage] = useState('');
  const { formatFromUSD, currency } = useCurrency();
  const { user } = useAuth();

  const handlePaymentSuccess = (paymentId: string, receiptUrl?: string) => {
    toast.success('Contribution submitted successfully!');
    console.log('Payment ID:', paymentId, 'Receipt:', receiptUrl);
    // Here you would update the UI to reflect the payment
  };

  const handleSendMessage = () => {
    if (message.trim()) {
      toast.success('Message sent to circle');
      setMessage('');
    }
  };

  const nextRecipient = circle.currentMembers.find((m) => m.userId === circle.nextPayoutRecipient);
  const paidMembers = circle.currentMembers.filter((m) => m.contributionStatus === 'paid');
  const pendingMembers = circle.currentMembers.filter((m) => m.contributionStatus === 'pending');

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50/50 to-white">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <ol className="flex items-center gap-2 text-sm">
            <li>
              <Link href="/dashboard" className="text-teal-600 hover:underline">
                Dashboard
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li className="text-gray-600">{circle.name}</li>
          </ol>
        </nav>

        {/* Header */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm mb-6">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="font-display text-2xl lg:text-3xl font-bold text-teal-900">
                  {circle.name}
                </h1>
                <Badge
                  className={
                    circle.type === 'rotating'
                      ? 'bg-teal-100 text-teal-700'
                      : circle.type === 'target'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-rose-100 text-rose-700'
                  }
                >
                  {circle.type}
                </Badge>
                <Badge
                  className={
                    circle.status === 'active'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-gray-100 text-gray-700'
                  }
                >
                  {circle.status}
                </Badge>
              </div>
              <p className="text-gray-600 mb-4">{circle.description}</p>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-gray-500">
                  Invite Code:{' '}
                  <span className="font-mono font-bold text-teal-700">{circle.inviteCode}</span>
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(circle.inviteCode);
                    toast.success('Invite code copied!');
                  }}
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </Button>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                className="bg-gradient-to-r from-teal-600 to-teal-500"
                onClick={() => setIsPaymentModalOpen(true)}
              >
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
                Contribute {formatFromUSD(circle.contributionAmount)}
              </Button>

              {/* Payment Modal */}
              <PaymentModal
                isOpen={isPaymentModalOpen}
                onClose={() => setIsPaymentModalOpen(false)}
                amount={circle.contributionAmount}
                circleId={circle.id}
                circleName={circle.name}
                userId={user?.id || '1'}
                cycle={circle.currentCycle}
                onSuccess={handlePaymentSuccess}
              />
              <Button variant="outline">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
                Invite
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <p className="text-sm text-gray-500">Total Pot</p>
            <p className="text-2xl font-bold text-green-700">{formatFromUSD(circle.totalPot)}</p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <p className="text-sm text-gray-500">Current Cycle</p>
            <p className="text-2xl font-bold text-teal-800">
              {circle.currentCycle}/{circle.totalCycles}
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <p className="text-sm text-gray-500">Contribution</p>
            <p className="text-2xl font-bold text-teal-800">
              {formatFromUSD(circle.contributionAmount)}/{circle.frequency.slice(0, 2)}
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
            <p className="text-sm text-gray-500">Members</p>
            <p className="text-2xl font-bold text-teal-800">
              {circle.currentMembers.length}/{circle.totalMembers}
            </p>
          </div>
        </div>

        {/* Next Payout Banner */}
        {nextRecipient && (
          <div className="bg-gradient-to-r from-amber-500 to-amber-400 rounded-2xl p-6 mb-6 text-white">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-3xl">🎉</span>
                </div>
                <div>
                  <p className="text-amber-100 text-sm">Next Payout</p>
                  <p className="text-2xl font-bold">{nextRecipient.name}</p>
                  <p className="text-amber-100">
                    receives {formatFromUSD(circle.contributionAmount * circle.totalMembers)} on{' '}
                    {circle.nextPayoutDate.toLocaleDateString()}
                  </p>
                </div>
              </div>
              <Avatar className="w-16 h-16 border-4 border-white/30">
                <AvatarImage src={nextRecipient.avatar} />
                <AvatarFallback>{nextRecipient.name.charAt(0)}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        )}

        {/* Progress */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold text-teal-900">Cycle Progress</h2>
            <span className="text-sm text-gray-500">
              {paidMembers.length}/{circle.currentMembers.length} paid
            </span>
          </div>
          <Progress value={(paidMembers.length / circle.currentMembers.length) * 100} className="h-4" />
          <div className="flex justify-between mt-2 text-sm text-gray-500">
            <span>{currency.symbol}0</span>
            <span>
              {formatFromUSD(circle.contributionAmount * circle.currentMembers.length)}
            </span>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="members" className="space-y-6">
          <TabsList className="bg-white border">
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="schedule">Payout Schedule</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
          </TabsList>

          <TabsContent value="members">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y">
              {circle.currentMembers.map((member, index) => (
                <div key={member.userId} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <span className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center text-sm font-bold text-teal-700">
                      {index + 1}
                    </span>
                    <Avatar>
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-teal-900">{member.name}</p>
                      <p className="text-sm text-gray-500">Trust Score: {member.trustScore}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm text-gray-500">This Cycle</p>
                      <Badge
                        className={
                          member.contributionStatus === 'paid'
                            ? 'bg-green-100 text-green-700'
                            : member.contributionStatus === 'pending'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-red-100 text-red-700'
                        }
                      >
                        {member.contributionStatus}
                      </Badge>
                    </div>
                    {member.hasReceivedPayout && (
                      <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y">
              {mockActivities.map((activity) => (
                <div key={activity.id} className="p-4 flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      activity.type === 'contribution'
                        ? 'bg-green-100 text-green-600'
                        : activity.type === 'payout'
                          ? 'bg-amber-100 text-amber-600'
                          : 'bg-blue-100 text-blue-600'
                    }`}
                  >
                    {activity.type === 'contribution' && '$'}
                    {activity.type === 'payout' && '💰'}
                    {activity.type === 'reminder' && '🔔'}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold text-teal-900">{activity.userName}</span>{' '}
                      {activity.message}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      {activity.createdAt.toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="schedule">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <h3 className="font-display text-lg font-bold text-teal-900 mb-4">Payout Schedule</h3>
              <div className="space-y-4">
                {circle.currentMembers.map((member, index) => (
                  <div
                    key={member.userId}
                    className={`flex items-center justify-between p-4 rounded-xl ${
                      index + 1 === circle.currentCycle
                        ? 'bg-amber-50 border-2 border-amber-200'
                        : index + 1 < circle.currentCycle
                          ? 'bg-gray-50'
                          : 'bg-white border border-gray-100'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span
                        className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                          index + 1 < circle.currentCycle
                            ? 'bg-green-100 text-green-700'
                            : index + 1 === circle.currentCycle
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {index + 1 < circle.currentCycle ? '✓' : index + 1}
                      </span>
                      <Avatar>
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-gray-900">{member.name}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-teal-800">
                        {formatFromUSD(circle.contributionAmount * circle.totalMembers)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {index + 1 < circle.currentCycle
                          ? 'Completed'
                          : index + 1 === circle.currentCycle
                            ? 'Current'
                            : `Cycle ${index + 1}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="chat">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
              <div className="h-96 overflow-y-auto p-4 space-y-4">
                {[
                  { user: 'Marie Jean-Baptiste', message: 'Just paid for this cycle! 💪', time: '2 hours ago' },
                  { user: 'Kwame Asante', message: 'Great! I\'ll send mine tomorrow.', time: '1 hour ago' },
                  { user: 'Rosa Martinez', message: 'Reminder: payments due by Friday!', time: '30 min ago' },
                ].map((msg, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback>{msg.user.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-teal-900">{msg.user}</span>
                        <span className="text-xs text-gray-400">{msg.time}</span>
                      </div>
                      <p className="text-gray-700 text-sm">{msg.message}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t p-4">
                <div className="flex gap-3">
                  <Input
                    placeholder="Send a message to the group..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage}>Send</Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
