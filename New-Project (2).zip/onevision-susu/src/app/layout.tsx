import type { Metadata } from "next";
import { Toaster } from "sonner";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import { CurrencyProvider } from "@/context/CurrencyContext";
import { PaymentProvider } from "@/context/PaymentContext";

export const metadata: Metadata = {
  title: "OneVision Susu | Community Savings Made Simple",
  description: "Your trusted community savings hub. Join a susu, sou-sou, or savings circle — the traditional way to build wealth together, now digital and transparent. Nou pale Kreyol!",
  keywords: "susu, sou-sou, rotating savings, community savings, ROSCA, Haitian savings, Caribbean savings, Queens savings, family savings, group savings",
  openGraph: {
    title: "OneVision Susu | Save Together, Grow Together",
    description: "Join thousands of families building wealth through trusted savings circles. Digital, transparent, and secure.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen">
        <AuthProvider>
          <CurrencyProvider>
            <PaymentProvider>
              {children}
              <Toaster position="top-right" richColors />
            </PaymentProvider>
          </CurrencyProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
