'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { mockCircles, mockNotifications, mockActivities } from '@/lib/mock-data';
import { useCurrency } from '@/context/CurrencyContext';

export default function DashboardPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  const { formatFromUSD, currency } = useCurrency();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, router]);

  if (!isAuthenticated || !user) {
    return null;
  }

  const userCircles = mockCircles.slice(0, 2);
  const unreadNotifications = mockNotifications.filter((n) => !n.read);

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50/50 to-white">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl font-bold text-teal-900">
                Welcome back, {user.name.split(' ')[0]}!
              </h1>
              <p className="text-gray-600 mt-1">
                Here's an overview of your savings circles and upcoming activities.
              </p>
            </div>
            <div className="flex gap-3">
              <Button asChild variant="outline" className="border-teal-200">
                <Link href="/circles/join">
                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                  </svg>
                  Join Circle
                </Link>
              </Button>
              <Button asChild className="bg-gradient-to-r from-teal-600 to-teal-500">
                <Link href="/circles/create">
                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Create Circle
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-500">Active Circles</p>
                <p className="text-2xl font-bold text-teal-900">{userCircles.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Contributed</p>
                <p className="text-2xl font-bold text-green-700">{formatFromUSD(800)}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-500">Next Payout</p>
                <p className="text-2xl font-bold text-amber-700">5 days</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-gray-500">Trust Score</p>
                <p className="text-2xl font-bold text-purple-700">{user.trustScore}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Circles */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-teal-900">My Circles</h2>
              <Link href="/circles" className="text-sm text-teal-600 hover:underline">
                View all
              </Link>
            </div>

            {userCircles.map((circle) => (
              <Link
                key={circle.id}
                href={`/circles/${circle.id}`}
                className="block bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="flex flex-col md:flex-row md:items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-display text-lg font-bold text-teal-900">
                        {circle.name}
                      </h3>
                      <Badge
                        variant="secondary"
                        className={
                          circle.type === 'rotating'
                            ? 'bg-teal-100 text-teal-700'
                            : circle.type === 'target'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-rose-100 text-rose-700'
                        }
                      >
                        {circle.type}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm mb-4">{circle.description}</p>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Contribution</p>
                        <p className="font-semibold text-teal-800">
                          {formatFromUSD(circle.contributionAmount)}/{circle.frequency}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">Total Pot</p>
                        <p className="font-semibold text-green-700">
                          {formatFromUSD(circle.totalPot)}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">Cycle</p>
                        <p className="font-semibold text-teal-800">
                          {circle.currentCycle}/{circle.totalCycles}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">Members</p>
                        <p className="font-semibold text-teal-800">
                          {circle.currentMembers.length}/{circle.totalMembers}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4">
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-gray-500">Circle Progress</span>
                        <span className="font-medium text-teal-700">
                          {Math.round((circle.currentCycle / circle.totalCycles) * 100)}%
                        </span>
                      </div>
                      <Progress
                        value={(circle.currentCycle / circle.totalCycles) * 100}
                        className="h-2"
                      />
                    </div>
                  </div>

                  <div className="flex md:flex-col items-center gap-3">
                    <div className="flex -space-x-2">
                      {circle.currentMembers.slice(0, 3).map((member, i) => (
                        <Avatar key={i} className="w-8 h-8 border-2 border-white">
                          <AvatarImage src={member.avatar} />
                          <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                      ))}
                      {circle.currentMembers.length > 3 && (
                        <div className="w-8 h-8 rounded-full bg-teal-100 border-2 border-white flex items-center justify-center text-xs font-medium text-teal-700">
                          +{circle.currentMembers.length - 3}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}

            {/* Recent Activity */}
            <div className="mt-8">
              <h2 className="font-display text-xl font-bold text-teal-900 mb-4">Recent Activity</h2>
              <div className="bg-white rounded-2xl border border-gray-100 divide-y">
                {mockActivities.slice(0, 5).map((activity) => (
                  <div key={activity.id} className="p-4 flex items-start gap-4">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        activity.type === 'contribution'
                          ? 'bg-green-100 text-green-600'
                          : activity.type === 'payout'
                            ? 'bg-amber-100 text-amber-600'
                            : activity.type === 'reminder'
                              ? 'bg-blue-100 text-blue-600'
                              : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {activity.type === 'contribution' && (
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                      )}
                      {activity.type === 'payout' && (
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      )}
                      {activity.type === 'reminder' && (
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm">
                        <span className="font-semibold text-teal-900">{activity.userName}</span>{' '}
                        <span className="text-gray-600">{activity.message}</span>
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {activity.createdAt.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Notifications */}
            <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-lg font-bold text-teal-900">Notifications</h3>
                {unreadNotifications.length > 0 && (
                  <Badge className="bg-red-500">{unreadNotifications.length}</Badge>
                )}
              </div>
              <div className="space-y-3">
                {mockNotifications.slice(0, 3).map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-xl ${
                      notif.read ? 'bg-gray-50' : 'bg-teal-50 border border-teal-100'
                    }`}
                  >
                    <p className="text-sm font-medium text-teal-900">{notif.title}</p>
                    <p className="text-xs text-gray-600 mt-1">{notif.message}</p>
                  </div>
                ))}
              </div>
              <Link
                href="/notifications"
                className="block mt-4 text-center text-sm text-teal-600 hover:underline"
              >
                View all notifications
              </Link>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-teal-600 to-teal-700 rounded-2xl p-6 text-white">
              <h3 className="font-display text-lg font-bold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button asChild variant="secondary" className="w-full justify-start">
                  <Link href="/contribute">
                    <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Make a Contribution
                  </Link>
                </Button>
                <Button asChild variant="secondary" className="w-full justify-start">
                  <Link href="/invite">
                    <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                    Invite Friends
                  </Link>
                </Button>
                <Button asChild variant="secondary" className="w-full justify-start">
                  <Link href="/profile">
                    <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    Edit Profile
                  </Link>
                </Button>
              </div>
            </div>

            {/* Help */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">🇭🇹</span>
                </div>
                <div>
                  <p className="font-semibold text-amber-900">Nou la pou ou!</p>
                  <p className="text-xs text-amber-700">We're here for you!</p>
                </div>
              </div>
              <p className="text-sm text-amber-800">
                Need help with your circle? Our team speaks English, Kreyol, and Spanish.
              </p>
              <Button asChild variant="outline" className="w-full mt-4 border-amber-300 text-amber-700 hover:bg-amber-100">
                <Link href="/contact">Contact Support</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
