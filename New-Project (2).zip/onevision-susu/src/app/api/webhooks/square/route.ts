import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

const SQUARE_WEBHOOK_SIGNATURE_KEY = process.env.SQUARE_WEBHOOK_SIGNATURE_KEY || '';

// Verify Square webhook signature
function verifyWebhookSignature(
  body: string,
  signature: string,
  webhookUrl: string
): boolean {
  if (!SQUARE_WEBHOOK_SIGNATURE_KEY) {
    console.warn('Square webhook signature key not configured');
    return false;
  }

  const hmac = crypto.createHmac('sha256', SQUARE_WEBHOOK_SIGNATURE_KEY);
  hmac.update(webhookUrl + body);
  const expectedSignature = 'sha256=' + hmac.digest('base64');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get('x-square-hmacsha256-signature') || '';
    const webhookUrl = `${request.nextUrl.origin}/api/webhooks/square`;

    // Verify signature in production
    if (process.env.NODE_ENV === 'production') {
      if (!verifyWebhookSignature(body, signature, webhookUrl)) {
        console.error('Invalid Square webhook signature');
        return NextResponse.json(
          { error: 'Invalid signature' },
          { status: 401 }
        );
      }
    }

    const event = JSON.parse(body);
    const { type, data } = event;

    console.log('Square webhook received:', type);

    switch (type) {
      case 'payment.completed': {
        const payment = data.object.payment;
        console.log('Payment completed:', payment.id);

        // Extract circle info from reference_id
        const referenceId = payment.reference_id;
        if (referenceId) {
          const [circleId, userId, cycle] = referenceId.split('-');

          // Here you would:
          // 1. Update the contribution record in your database
          // 2. Mark the member's contribution as 'paid' for this cycle
          // 3. Check if all members have paid
          // 4. If all paid, trigger payout to the recipient

          console.log(`Processing contribution: Circle ${circleId}, User ${userId}, Cycle ${cycle}`);
        }
        break;
      }

      case 'payment.failed': {
        const payment = data.object.payment;
        console.log('Payment failed:', payment.id);

        // Handle failed payment
        // Notify user, update records, etc.
        break;
      }

      case 'refund.created': {
        const refund = data.object.refund;
        console.log('Refund created:', refund.id);

        // Handle refund
        // Update contribution records, notify admin, etc.
        break;
      }

      case 'customer.created': {
        const customer = data.object.customer;
        console.log('Customer created:', customer.id);
        break;
      }

      default:
        console.log('Unhandled webhook event:', type);
    }

    return NextResponse.json({ received: true });

  } catch (error) {
    console.error('Square webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    );
  }
}
