import { NextRequest, NextResponse } from 'next/server';
import { squareClient, type CardOnFileRequest, type CardOnFileResult } from '@/lib/square';
import { v4 as uuidv4 } from 'uuid';

// Save a card on file for recurring payments
export async function POST(request: NextRequest) {
  try {
    const body: CardOnFileRequest = await request.json();

    const { customerId, sourceId, cardholderName } = body;

    if (!customerId || !sourceId) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const response = await squareClient.cards.create({
      idempotencyKey: uuidv4(),
      sourceId,
      card: {
        customerId,
        cardholderName,
      },
    });

    const card = response.card;

    if (card) {
      const cardResult: CardOnFileResult = {
        success: true,
        cardId: card.id,
        last4: card.last4,
        cardBrand: card.cardBrand,
      };

      return NextResponse.json(cardResult);
    }

    return NextResponse.json(
      { success: false, error: 'Failed to save card' },
      { status: 400 }
    );

  } catch (error) {
    console.error('Square card error:', error);

    if (error && typeof error === 'object' && 'errors' in error) {
      const squareError = error as { errors: Array<{ detail: string }> };
      return NextResponse.json(
        {
          success: false,
          error: squareError.errors?.[0]?.detail || 'Card save failed',
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Get customer's saved cards
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const customerId = searchParams.get('customerId');

    if (!customerId) {
      return NextResponse.json(
        { success: false, error: 'Customer ID required' },
        { status: 400 }
      );
    }

    const response = await squareClient.cards.list({ customerId });

    // The list response is paginated, collect all cards
    const cards = [];
    for await (const card of response) {
      cards.push({
        id: card.id,
        last4: card.last4,
        cardBrand: card.cardBrand,
        expMonth: card.expMonth,
        expYear: card.expYear,
      });
    }

    return NextResponse.json({
      success: true,
      cards: cards.map((card) => ({
        id: card.id,
        last4: card.last4,
        cardBrand: card.cardBrand,
        expMonth: card.expMonth ? Number(card.expMonth) : undefined,
        expYear: card.expYear ? Number(card.expYear) : undefined,
      })),
    });

  } catch (error) {
    console.error('Square list cards error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to list cards' },
      { status: 500 }
    );
  }
}
