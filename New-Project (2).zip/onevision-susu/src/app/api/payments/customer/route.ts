import { NextRequest, NextResponse } from 'next/server';
import { squareClient, type CustomerRequest, type CustomerResult } from '@/lib/square';
import { v4 as uuidv4 } from 'uuid';

// Create or retrieve a Square customer
export async function POST(request: NextRequest) {
  try {
    const body: CustomerRequest = await request.json();

    const { email, givenName, familyName, phoneNumber, referenceId } = body;

    if (!email || !givenName || !referenceId) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // First, try to find existing customer by reference ID
    const searchResponse = await squareClient.customers.search({
      query: {
        filter: {
          referenceId: {
            exact: referenceId,
          },
        },
      },
    });

    if (searchResponse.customers && searchResponse.customers.length > 0) {
      // Customer already exists
      const customer = searchResponse.customers[0];
      return NextResponse.json({
        success: true,
        customerId: customer.id,
        isExisting: true,
      });
    }

    // Create new customer
    const createResponse = await squareClient.customers.create({
      idempotencyKey: uuidv4(),
      givenName,
      familyName,
      emailAddress: email,
      phoneNumber,
      referenceId,
      note: 'OneVision Susu Member',
    });

    const customerResult: CustomerResult = {
      success: true,
      customerId: createResponse.customer?.id,
    };

    return NextResponse.json(customerResult);

  } catch (error) {
    console.error('Square customer error:', error);

    if (error && typeof error === 'object' && 'errors' in error) {
      const squareError = error as { errors: Array<{ detail: string }> };
      return NextResponse.json(
        {
          success: false,
          error: squareError.errors?.[0]?.detail || 'Customer creation failed',
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
