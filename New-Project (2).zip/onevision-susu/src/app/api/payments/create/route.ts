import { NextRequest, NextResponse } from 'next/server';
import { squareClient, dollarsToCents, type PaymentRequest, type PaymentResult } from '@/lib/square';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  try {
    const body: PaymentRequest = await request.json();

    const { sourceId, amount, currency, circleId, userId, cycle, note } = body;

    // Validate required fields
    if (!sourceId || !amount || !circleId || !userId) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Generate idempotency key
    const idempotencyKey = body.idempotencyKey || uuidv4();

    // Create payment with Square
    const response = await squareClient.payments.create({
      sourceId,
      idempotencyKey,
      amountMoney: {
        amount: dollarsToCents(amount),
        currency: (currency || 'USD') as 'USD' | 'EUR' | 'HTG',
      },
      autocomplete: true,
      note: note || `OneVision Susu - Circle ${circleId} - Cycle ${cycle}`,
      referenceId: `${circleId}-${userId}-${cycle}`,
      statementDescriptionIdentifier: 'ONEVISION SUSU',
    });

    const payment = response.payment;

    if (payment && payment.status === 'COMPLETED') {
      const paymentResult: PaymentResult = {
        success: true,
        paymentId: payment.id,
        receiptUrl: payment.receiptUrl,
      };

      // Here you would also:
      // 1. Store the payment record in your database
      // 2. Update the member's contribution status
      // 3. Check if all members have paid for the cycle
      // 4. Trigger payout if applicable

      return NextResponse.json(paymentResult);
    }

    return NextResponse.json(
      {
        success: false,
        error: `Payment ${payment?.status || 'failed'}`,
        paymentId: payment?.id,
      },
      { status: 400 }
    );

  } catch (error) {
    console.error('Square payment error:', error);

    // Handle Square API errors
    if (error && typeof error === 'object' && 'errors' in error) {
      const squareError = error as { errors: Array<{ detail: string }> };
      return NextResponse.json(
        {
          success: false,
          error: squareError.errors?.[0]?.detail || 'Payment processing failed',
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
